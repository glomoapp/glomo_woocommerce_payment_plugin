<?php
/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter('woocommerce_payment_gateways', 'glomo_add_gateway_class');
function glomo_add_gateway_class($gateways)
{
  $gateways[] = 'WC_Glomo_Gateway'; // your class name is here
  return $gateways;
}
 add_action('wp_ajax_nopriv_make_payment_initiate','make_payment_initiate');
add_action('wp_ajax_make_payment_initiate','make_payment_initiate');

add_action('wp_ajax_nopriv_make_payment_valider','make_payment_valider');
add_action('wp_ajax_make_payment_valider','make_payment_valider');

add_action('wp_ajax_nopriv_make_payment_resendSms','make_payment_resendSms');
add_action('wp_ajax_make_payment_resendSms','make_payment_resendSms');
 function make_payment_initiate()
    {
      

      //To receive order id 
      $order = new WC_Order($_GET['order_id']);

      //To receive order amount
      $amount = $order->get_total();

      $number = strip_tags($_POST['number']);

      //Create a session and send it to Payment platform while handling errors 
      
      

      $param['option'] = WC_Glomo_Gateway::API_URL . WC_Glomo_Gateway::API_INI;
      $request=new WC_Glomo_Gateway();
      $data = array(
        "amount" => $amount,
        "title" => $request->title,
        "numero" => $number,
      );
      $reponse = $request->request($data, $param);
      // $reponse->url=$this->siteUrl . "//wc-api/glomo_payment_valider";
      echo json_encode($reponse);
      die;
    }
    
     function make_payment_valider()
    {
      

      $orderId = $_POST['orderId'];
     

      // Getting POST data
      $data = [
        'key' => strip_tags($_POST['key']),
        'code_app' => strip_tags($_POST['code_app']),
        'code_sms' => strip_tags($_POST['code_sms']),
      ];
     

      $param['option'] = WC_Glomo_Gateway::API_URL . WC_Glomo_Gateway::API_VALIDER;
      $request=new WC_Glomo_Gateway();
      $reponse = $request->request($data, $param);
      switch ($reponse->status) {
        case 'OK':
          WC_Glomo_Gateway::glomo_complete_payment($orderId);
          $customer_order = new WC_Order($orderId);
          $reponse->redirect=WC_Glomo_Gateway::forceRedirect($customer_order);
          break;

        default:
         WC_Glomo_Gateway::glomo_fail_payment($orderId);
          break;
      }
      echo json_encode($reponse);
      die;
    }

     function make_payment_resendSms()
    {

      $data = [
        'key' => $_POST['key'],
      ];
      
      $param['option'] = WC_Glomo_Gateway::API_URL . WC_Glomo_Gateway::API_RESEND;
      $request=new WC_Glomo_Gateway();
      $reponse = $request->request($data, $param);

      echo json_encode($reponse); die;
    }
/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action('plugins_loaded', 'glomo_init_gateway_class');
function glomo_init_gateway_class()
{

  

  class WC_Glomo_Gateway extends WC_Payment_Gateway
  {

    /**
     * Class constructor, more about it in Step 3
     */
    const GATEWAY = 'glomo';
    const API_URL = "https://apis.glomoapp.com/v1";
    const API_INI = "/account/debit/initiate";
    const API_VALIDER = "/account/debit/valid";
    const API_TOKEN = "/token/generate";
    const API_RESEND = "/account/operation/code/sms/resend";
    const WOOCOMMERCE_RETURN_URI = '/glomo/woocommerce/return';
    const WOOCOMMERCE_NOTIFY_URI = '/glomo/woocommerce/notify';
    const STATUS_SUCCESS ="ok";
    const STATUS_FAILED = "not ok";
    public function __construct()
    {

      $this->id = 'glomo'; // payment gateway plugin ID
      $this->icon = ''; // URL of the icon that will be displayed on checkout page near your gateway name
      $this->has_fields = true; // in case you need a custom credit card form
      $this->method_title = 'Glomo Money Gateway';
      $this->method_description = 'Description of Glomo Money payment gateway'; // will be displayed on the options page

      // gateways can support subscriptions, refunds, saved payment methods,
      // but in this tutorial we begin with simple payments
      $this->supports = array(
        'products'
      );

      // Method with all the options fields
      $this->init_form_fields();

      // Load the settings.
      $this->init_settings();
      $this->title = $this->get_option('title');
      $this->description = $this->get_option('description');
      $this->enabled = $this->get_option('enabled');
      $this->testmode = 'yes' === $this->get_option('testmode');
      $this->api_key = $this->get_option('api_key');
      $this->api_secret = $this->get_option('api_secret');
      $this->api_token =  $this->get_option('api_token');
      $this->order_button_text = __('Pay by Glomo Money', WC_Glomo_Gateway::GATEWAY);
      $this->has_fields = true;
      // This action hook saves the settings
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
      add_action('woocommerce_receipt_' . $this->id, array($this, 'payment_page'));
      // We need custom JavaScript to obtain a token
      add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
      add_action('wp_enqueue_style', array($this, 'payment_style'));

      ;
      add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'glomo_woocommerce_actions_links', 10, 1);
    }

    /**
     * Plugin options, we deal with it in Step 3 too
     */
    public function init_form_fields()
    {

      $this->form_fields = array(
        'enabled' => array(
          'title'       => 'Enable/Disable',
          'label'       => 'Enable Glomo Money Gateway',
          'type'        => 'checkbox',
          'description' => '',
          'default'     => 'no'
        ),
        'title' => array(
          'title'       => 'Title',
          'type'        => 'text',
          'description' => 'This controls the title which the user sees during checkout.',
          'default'     => 'Glomo Money',
          'desc_tip'    => true,
        ),
        'description' => array(
          'title'       => 'Description',
          'type'        => 'textarea',
          'description' => 'This controls the description which the user sees during checkout.',
          'default'     => 'Pay with your Glomo Money account via our super-cool payment gateway.',
        ),
        'testmode' => array(
          'title'       => 'Test mode',
          'label'       => 'Enable Test Mode',
          'type'        => 'checkbox',
          'description' => 'Place the payment gateway in test mode using test API keys.',
          'default'     => 'yes',
          'desc_tip'    => true,
        ),
        'api_key' => array(
          'title'       => 'APP-ID-KEY ',
          'type'        => 'text'
        ),
        'api_secret' => array(
          'title'       => 'APP-SECRET-KEY',
          'type'        => 'text',
        ),
        'api_token' => array(
          'title'       => 'APP-TOKEN',
          'type'        => 'text'
        ),
        'label' => array(
          'title'       => 'SERVICE NAME',
          'type'        => 'text'
        )
      );
    }
    

    function glomo_woocommerce_actions_links($actions)
    {
      $custom_actions = array(
        'Create An Account' => '<a href="https://developer.glomoapp.com/register" target="_blank">' . __('Create An Account', 'glomo') . '</a>',
        'Create new service' => '<a href="https://developer.glomoapp.com/" target="_blank">' . __('Create new service', 'glomo') . '</a>'
      );

      return array_merge($custom_actions, $actions);
    }
    public static function isGlomoWoocommerceReturnPage()
    {
      $uri = WC_Glomo_Gateway::getUri();

      if (false === stripos($uri, WC_Glomo_Gateway::WOOCOMMERCE_RETURN_URI)) {
        return false;
      }

      return true;
    }
    public static function isGlomoWoocommerceNotify()
        {
            $uri = WC_Glomo_Gateway::getUri();

            if (false === stripos($uri, WC_Glomo_Gateway::WOOCOMMERCE_NOTIFY_URI)) {
                return false;
            }

            return true;
        }
    public static function getServerUrl()
    {
      return get_site_url();
    }

    /**
     * @return string | null
     */
    public static function getUrl()
    {
      $url = WC_Glomo_Gateway::getServerUrl() . WC_Glomo_Gateway::getUri();
      return $url;
    }

    /**
     * @return string | null
     */
    public static function getUri()
    {
      $requestUri = $_SERVER['REQUEST_URI'];
      $uri = '/' . ltrim($requestUri, '/');

      return $uri;
    }
    
    /*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
    public function payment_scripts()
    {


          // and this is our custom JS in your plugin directory that works with token.js
            wp_register_script( "woocommerce_glomo_jquery", plugin_dir_url(__FILE__).'../assets/js/jquery-2.1.4.min.js', array('jquery') );
            wp_register_script( "woocommerce_glomo", plugin_dir_url(__FILE__).'../assets/js/glomo.js', array('jquery') );
            wp_register_style('woocommerce_glomo_style',plugin_dir_url(__FILE__).'../assets/css/style.css', array());
            wp_enqueue_script( 'woocommerce_glomo_jquery' );
            wp_enqueue_script( 'woocommerce_glomo' );
            wp_enqueue_style( 'woocommerce_glomo_style' );
    }
    
    
    
    public function payment_page($order_id)
    {
      // Get this Order's information so that we know
      // who to charge and how much
      $customer_order = new WC_Order($order_id);

      $payment_url=admin_url('admin-ajax.php?order_id='.$order_id);
      $action="make_payment_initiate";
      $action2="make_payment_valider";
      wp_enqueue_script('monetbil-wcc-widget-v2');


      ($payment_url);($action);($action2);

      include 'templates/receipt.php';
    }
    
    

    public function process_payment($order_id)
    {
      // Get this Order's information so that we know
      // who to charge and how much
      $customer_order = new WC_Order($order_id);

      $payment_url = $customer_order->get_checkout_payment_url(true);


      return array(
        'result' => 'success',
        'redirect' => $payment_url
      );
    }
    /*
		 * We're processing the payments here, everything about it is in Step 5
		 */
    

    
    public static function redirectToCheckout()
    {
      global $woocommerce;
      $checkout_url = $woocommerce->cart->get_checkout_url();
      wp_redirect($checkout_url);
      exit;
    }
    public static function forceRedirect($customer_order)
    {
      $module = new WC_Glomo_Gateway();

      return$module->get_return_url($customer_order) ;
    }

    public static function glomo_complete_payment($orderId)
    {
      $order = wc_get_order($orderId);
      $order->update_status('completed');
                $order->payment_complete();
                $order->reduce_order_stock();
                WC()->cart->empty_cart();
    }
    
    public static function glomo_fail_payment($orderId)
    {
      $order = wc_get_order($orderId);
      $order->update_status('failed');
    }

    /**
     * getPost
     *
     * @param string $key
     * @param string $default
     * @return string
     */
    public static function getPost($key = null, $default = null)
    {
        return $key == null ? $_POST : (isset($_POST[$key]) ? $_POST[$key] : $default);
    }

    /**
     * getQuery
     *
     * @param string $key
     * @param string $default
     * @return string
     */
    public static function getQuery($key = null, $default = null)
    {
        return $key == null ? $_GET : (isset($_GET[$key]) ? $_GET[$key] : $default);
    }

    /**
     * getQueryParams
     *
     * @return array
     */
    public static function getQueryParams()
    {
        $queryParams = array();
        $parts = explode('?', WC_Glomo_Gateway::getUrl());

        if (isset($parts[1])) {
            parse_str($parts[1], $queryParams);
        }

        return $queryParams;
    }

    public function request($data, $param)
    {
      $url = $param['option'];
      // in this example, POST request was made using PHP's CURL
      $heard= array(
        'App-Id: ' . $this->api_key,
        'App-Secret:' . $this->api_secret,
        'Authorisation: Bearer ' . $this->api_token,
        'Content-Type: application/json',
        'Accept: application/json',
      );
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
      curl_setopt($ch, CURLOPT_HTTPHEADER, $heard);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $response = curl_exec($ch);
      $err = curl_error($ch);
      curl_close($ch);
      return json_decode($response);
    }
  }
}
