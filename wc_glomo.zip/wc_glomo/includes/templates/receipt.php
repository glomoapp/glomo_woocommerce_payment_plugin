<?php

/**
 * Remove default styles
 */
ob_start();

wp_head();

$linesh = explode("\n", ob_get_clean());
foreach ($linesh as $value) {

    if (false !== stripos($value, '/plugins/wc_glomo/assets/css')) {
        echo $value;
    }
}

include 'payment-widget-v2.php';


/**
 * Remove default scripts
 */
ob_start();

wp_footer();

$linesf = explode("\n", ob_get_clean());
foreach ($linesf as $value) {

    if (false !== stripos($value, '/plugins/wc_glomo/assets/js')) {
        echo $value;
    }
}