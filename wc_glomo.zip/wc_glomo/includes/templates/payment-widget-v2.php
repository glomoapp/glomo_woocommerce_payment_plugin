<form action="<?php echo $payment_url; ?>" method="post" id="formr">
    <input type="hidden" name="action" id="input" class="form-control" value="<?php echo $action; ?>">
    <div class="loading text-center mt--4 d-none">
        <span class="trans_titles mt-4" style="color:blue; font-size:20px;">Please Wait...</span>
        
    </div>
    <div class="canceltranse text-center mt--4 d-none">
        <span class="fa fa-times-circle fa-4x w-100" style="background-color: red; color:#FFFFFF" ></span>
    </div>
    <div class="response_messages text-center"></div>
    <div class="payform">
        <div class="col-md-12">
            <div class="form-group">
                <label for="">
                    Glomo account customer number <span class="required">*</span>
                </label>
                <div class="input-group">
                    <input class="input4" placeholder="account customer number" type="text" value="" name="number" required />
                </div>
            </div>
        </div>

    </div>
    
    
    <div class="buttons">
        <div class="pa-t">
            <button type="submit" class="button4 cmd" style="background-color:#4c804e" ><?php echo __('Pay by Glomo Money', WC_Glomo_Gateway::GATEWAY); ?>"</button>
        </div>
    </div>
</form>
<div class="glomo-modal" id="confirmP" style="min-width: 400px;">

    <form action="<?php echo $payment_url; ?>" id="formr2" method="post">
        <div class="glomo-modal-content">
            <span class="close">&times;</span>
            <div class="confirm">
                <div class="text-center">
                    <p class="trans_title"></p>
                </div>
                <input type="hidden" name="action" id="input" class="form-control" value="<?php echo $action2; ?>">
                <div class="col-md-12">
                    <div class="form-group text-left">
                        <label for="">
                            Secret Code
                        </label>
                        <div class="input-group">
                            <input class="input4" placeholder="Enter Secret code " type="text" value="" name="code_sms" id="code_sms" required />
                            <input type="hidden" name="code_app" id="code_app" />
                            <input type="hidden" name="key" id="key" />
                            <input type="hidden" name="orderId" id="orderId" value="<?php echo $order_id; ?>" />
                        </div>
                    </div>
                </div>
                <div class="text-center">
                    <p style="color:blue">
                        if you have not received the sms click on Resend
                    </p>
                    
                    <span class="resend_message"></span>
                </div>
            </div>
            <div class="loadinged d-none text-center mt--4">
                    <span style="color:blue; font-size:20px;">Please Wait...</span>
            </div>
            <div class="canceltrans text-center mt--4 d-none">
                <span class="fa fa-times-circle fa-4x w-100" style="background-color: red; color:#FFFFFF" ></span>
            </div>
            <div class="completetrans text-center mt--4 d-none">
                <span class="fa fa-check-circle fa-4x w-100" style="background-color: green; color:#FFFFFF" aria-hidden="true">

                </span>
            </div>
            <div class="response_message text-center"></div>
            <div class="modal-footer justify-content-around pa-t">
            <button type="button" class="button4 resend" style="background-color:#f14e4e" data-url="<?php echo $payment_url; ?>" data-key="" data-action="">
                        Resend Sms
                </button>
                <button type="submit" class="button4 cnf" style="background-color:#4c804e">
                    Confirm Payment
                </button>
            </div>
        </div>
    </form>
</div>

<style>
    
    /* Demo Styles */
</style>