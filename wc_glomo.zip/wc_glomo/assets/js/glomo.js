$(function ($) {
	var temps;
	var ispay = false;

	var glomo_modal = document.getElementById("confirmP");
	
	window.onclick = function(event) {
		if (event.target == glomo_modal) {
			glomo_modal.style.display = "none";
		}
	  }
	  $('.close').on('click', function (event) {
		
			glomo_modal.style.display = "none";
		 
	  });
	$("#formr").submit(function (e) {
		e.preventDefault();
		var fa = $(this);
		$('.loading').removeClass('d-none')
		$('.cmd').attr("disabled", true);
		$.ajax({
			url: fa.attr("action"),
			type: "post",
			data: fa.serialize(),
			dataType: "json",
			success: function (response) {
				if (response.status == "OK") {
					ispay = true;
					glomo_modal.style.display = "block";
					$('#code_app').val(response.cle_app);
					$('#key').val(response.cle_operation);
					$('#code_sms').val(response.cle_sms);
					$('.trans_titles').html("Confirme Payment");
					$('.trans_title').html(response.message);
					$('.resend').attr('data-url', response.url)
					$('.resend').attr('data-key', response.cle_operation)
					
					
				} else {
					ispay = false;
					$('.loading').addClass('d-none')
					$('.canceltranse').removeClass('d-none')
					$('.modal-footer').addClass('d-none')
					$(".response_messages").html('Transaction Failed');
					$(".trans_title").html(' Failed');
				}

			},
			error: function (error) { },
		});
	});

	$('#exampleModalCenter').on('hidden.bs.modal', function () {
		if (!ispay) {

			$('.investchek').prop("checked", false)
		}
		$('.loading').addClass('d-none')
		$('.payform').removeClass('d-none')

	});
	$("#formr2").submit(function (e) {
		e.preventDefault();
		var fa = $(this);
		$('.loadinged').removeClass('d-none')
		$('.confirm').addClass('d-none')
		$('.cnf').attr("disabled", true);
		$.ajax({
			url: fa.attr("action"),
			type: "post",
			data: fa.serialize(),
			dataType: "json",
			success: function (response) {
				if (response.status == "OK") {
					ispay = true;
					$('.loadinged').addClass('d-none')
					$('.completetrans').removeClass('d-none')
					$('.modal-footer').addClass('d-none')
					$(".response_message").html('Transaction Complete');
					$(".trans_title").html(' Complete');
					$(".respo").html('<span class="text-success">Payment Receive</span>');
					$(".investchek").val('OK');
					$(".investchek").attr('readonly', true);
					temps=setTimeout(function() { location.href=response.redirect; },3000);
				} else if (response.status == "NOT OK") {
					ispay = false;
					$('.loadinged').addClass('d-none')
					$('.canceltrans').removeClass('d-none')
					$('.modal-footer').addClass('d-none')
					$(".response_message").html('Transaction Failed');
					$(".trans_title").html(' Failed');
				}
			},
			error: function (error) { },
		});
	});

	$('.resend').on('click', function () {
		$.ajax({
			type: "post",
			url: $(this).attr('data-url'),
			data: { key: $(this).attr('data-key'), action:$(this).attr('data-action')},
			dataType: "json",
			success: function (response) {

				if (response.status == "NOT OK") {
					ispay = false;
					$(".resend_message").html('<span class="text-danger small">' + response.error_message + '</span>');
				} else {
					ispay = true;
					$('#code_sms').val(response.cle_sms);
					$(".resend_message").html('<span class="text-danger small">' + response.message + '</span>');
				}

			}
		});
	});
});