<?php 
/*
    *Plugin Name: Glomo Money WooCommerce Payment Gateway
    *Plugin URI: https://glomomoney.com/
    *Author: Glomo Money
    *Description: WooCommerce custom payment gateway integration on Glomo Money.
    *Version: 1.0
*/

require_once plugin_dir_path(__FILE__) . 'includes/glomo_function.php';